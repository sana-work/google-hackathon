---
description: Verify the key architecture rule: navigation updates context only, chat submission triggers BFF and AI workflow.
---

# Verify Chatbot Flow

Run or inspect the app and confirm:

## Navigation Flow

When user selects a Payments or Trade record:

Expected:
- business MFE emits `CHATBOT_CONTEXT_CHANGED`
- ChatbotMFE context updates
- no BFF request is made
- no AI request is made
- no token cost

## Chat Flow

When user sends message:

Expected:
- ChatbotMFE sends message + accumulated context to BFF
- BFF validates user
- BFF checks entitlement
- BFF enriches context server-side
- BFF redacts sensitive data
- BFF streams response via SSE

## Tests

Run:
- `pnpm test`
- `pnpm typecheck`
- `pnpm build`
- `bash scripts/verify-architecture.sh`

Check:
- frontend has no AI platform URL
- frontend has no API keys
- event payload contains no raw PII
