import React from "react";
import { createRoot } from "react-dom/client";
import { CHATBOT_CONTEXT_CHANGED, makeCorrelationId } from "@platform/contracts";
import "./style.css";

const payments = [
  { id: "PAY-1001", status: "Failed", amountBand: "High" },
  { id: "PAY-1002", status: "Pending Approval", amountBand: "Medium" }
];

function selectPayment(payment: (typeof payments)[number]) {
  window.dispatchEvent(new CustomEvent(CHATBOT_CONTEXT_CHANGED, {
    detail: {
      eventVersion: "1.0",
      sourceMfe: "PaymentsMFE",
      lob: "Payments",
      contextType: "payment_record_selected",
      contextId: payment.id,
      safeSummary: { status: payment.status, amountBand: payment.amountBand },
      classification: "confidential",
      timestamp: new Date().toISOString(),
      ttlSeconds: 900,
      correlationId: makeCorrelationId()
    }
  }));
}

function App() {
  return <main><h2>Payments MFE</h2>{payments.map((p) => <button key={p.id} onClick={() => selectPayment(p)}>{p.id} — {p.status}</button>)}</main>;
}

createRoot(document.getElementById("root")!).render(<App />);
