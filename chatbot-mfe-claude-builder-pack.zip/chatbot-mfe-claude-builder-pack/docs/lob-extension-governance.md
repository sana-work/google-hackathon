# LOB Extension Governance

## Three Rings

| Ring | Owner | Examples | LOB can change? |
|---|---|---|---|
| Locked | Central team | auth, entitlement, audit, redaction, BFF protocol, core conversation engine | No |
| Configurable | LOB through config | persona, greeting, suggested prompts, theme, feature flags | Yes, validated |
| Extensible | LOB through plugin API | tools, UI slots, lifecycle hooks, workflow triggers | Yes, reviewed |

## Extension Types

- Declarative config
- UI slots
- Domain tools
- Lifecycle hooks
- Workflow triggers
- Response renderers

Each extension type needs:

- schema validation
- owner
- review process
- permission model
- rollback strategy
- kill switch
- observability

## No Forking

LOBs must not fork or bypass the core ChatbotMFE.
