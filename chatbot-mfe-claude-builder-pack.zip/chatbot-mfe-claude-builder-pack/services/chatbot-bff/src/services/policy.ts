const PROMPT_INJECTION_PATTERNS = [
  /ignore previous instructions/i,
  /reveal system prompt/i,
  /bypass policy/i,
  /disable security/i,
  /show hidden/i
];

export function detectPromptInjection(message: string): boolean {
  return PROMPT_INJECTION_PATTERNS.some((pattern) => pattern.test(message));
}
