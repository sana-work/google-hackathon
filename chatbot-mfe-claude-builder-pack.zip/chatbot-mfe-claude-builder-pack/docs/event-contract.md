# Event Contract — Passive Context Propagation

## Event Name

```text
CHATBOT_CONTEXT_CHANGED
```

## Purpose

Business MFEs publish this event when the user changes context, such as selecting a payment or trade record.

This event must not cause a BFF or AI call.

## Allowed Payload

```ts
{
  eventVersion: "1.0";
  sourceMfe: "PaymentsMFE" | "TradeMFE" | string;
  lob: "Payments" | "Trade" | string;
  contextType: string;
  contextId: string;
  route?: string;
  safeSummary?: Record<string, string | number | boolean>;
  classification: "public" | "internal" | "confidential" | "restricted";
  permissionsHint?: Record<string, boolean>;
  timestamp: string;
  ttlSeconds: number;
  correlationId: string;
}
```

## Forbidden Payload

Do not emit:

- full raw business record
- full account number
- customer name
- SSN/tax ID
- beneficiary bank account
- private notes
- secrets
- API keys
- unredacted PII

## Debounce

Business MFEs should debounce context events, recommended 300ms.

## TTL

Context must expire. Recommended TTL: 900 seconds.

## Ordering

Consumers should ignore stale events by comparing timestamps and correlation IDs.
