Use the verify-chatbot-flow skill and qa-engineer agent.

Prove with code/tests that:
- selecting a Payments record emits a context event only
- selecting a Trade record emits a context event only
- no BFF call happens during navigation
- chat submit calls BFF
- BFF validates entitlement
- BFF redacts before prompt and logs
- SSE response streams to ChatbotMFE
