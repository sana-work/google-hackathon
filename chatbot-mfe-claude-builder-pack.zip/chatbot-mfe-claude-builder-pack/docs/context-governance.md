# Context Governance

## Principle

Context is metadata, not raw data.

The frontend should only tell the chatbot what the user is looking at. The BFF decides what full data the chatbot is allowed to use.

## Frontend Context

Allowed:

- LOB
- source MFE
- record type
- record ID
- safe status summary
- classification
- TTL
- correlation ID

Not allowed:

- raw payment/trade records
- customer names
- bank account numbers
- unrestricted PII
- private comments
- credentials

## Server-Side Enrichment

The BFF may fetch full business data only after:

- auth validation
- entitlement check
- data classification check
- purpose validation

## Restricted Content

Restricted content should not be sent raw to AI. Use:

- redacted summary
- masked identifiers
- approved retrieval path
- deny-by-default tool permissions

## Context Expiration

Context must expire by TTL and reset on domain switch where appropriate.
