import { describe, expect, it } from "vitest";
import { ChatbotContextEventSchema, CHATBOT_CONTEXT_CHANGED } from "./index";

describe("contracts", () => {
  it("exports context event name", () => {
    expect(CHATBOT_CONTEXT_CHANGED).toBe("CHATBOT_CONTEXT_CHANGED");
  });

  it("validates safe context", () => {
    const result = ChatbotContextEventSchema.safeParse({
      eventVersion: "1.0",
      sourceMfe: "PaymentsMFE",
      lob: "Payments",
      contextType: "payment_record_selected",
      contextId: "PAY-123",
      safeSummary: { status: "Failed" },
      classification: "confidential",
      timestamp: new Date().toISOString(),
      ttlSeconds: 900,
      correlationId: "corr-12345678"
    });

    expect(result.success).toBe(true);
  });
});
