import Fastify from "fastify";
import cors from "@fastify/cors";
import rateLimit from "@fastify/rate-limit";
import { registerChatRoutes } from "./routes/chat.js";

export function buildServer() {
  const app = Fastify({ logger: true });

  app.register(cors, { origin: true });
  app.register(rateLimit, { max: 60, timeWindow: "1 minute" });

  app.get("/health", async () => ({ status: "ok" }));
  app.register(registerChatRoutes, { prefix: "/api" });

  return app;
}

const app = buildServer();
const port = Number(process.env.BFF_PORT || 4000);

app.listen({ port, host: "0.0.0.0" }).catch((error) => {
  app.log.error(error);
  process.exit(1);
});
