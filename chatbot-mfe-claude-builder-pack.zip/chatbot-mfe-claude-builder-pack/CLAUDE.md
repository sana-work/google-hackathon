# CLAUDE.md — Chatbot MFE Platform Constitution

Claude Code must follow these instructions for every task in this repo.

## 1. Product Goal

Build a governed enterprise Chatbot MFE platform for a Services Shared Ops UI Platform.

The platform supports multiple business MFEs such as:

- PaymentsMFE
- TradeMFE
- InvestorMFE
- CoreAccountsMFE
- IDP MFE

The ChatbotMFE is mounted once by the Host Shell and acts as a sibling to business MFEs.

## 2. Non-Negotiable Rule

Navigation updates context only.
Chat submission triggers BFF / AI work.

Never make a backend call merely because the user navigated, selected a record, changed tabs, or changed routes.

## 3. Runtime Architecture

```text
Host Shell
  ├── PaymentsMFE
  ├── TradeMFE
  └── ChatbotMFE mounted once

Navigation/select record:
Business MFE → browser event → ChatbotMFE context update only

Chat message:
ChatbotMFE → Chatbot BFF → AI Platform / Business APIs / Workflow Engine
```

## 4. Frontend Rules

Frontend may:

- emit `CHATBOT_CONTEXT_CHANGED`
- store safe context summary
- submit chat message to BFF
- consume SSE response from BFF
- render chatbot UI

Frontend must not:

- call AI Platform directly
- call business APIs directly for chatbot enrichment
- store raw PII in sessionStorage
- emit raw business records in browser events
- include AI credentials, API keys, or service secrets

## 5. Event Rules

Business MFEs may emit:

```text
CHATBOT_CONTEXT_CHANGED
```

Allowed fields:

- eventVersion
- sourceMfe
- lob
- contextType
- contextId
- route
- safeSummary
- classification
- permissionsHint
- timestamp
- ttlSeconds
- correlationId

Forbidden fields:

- full account number
- customer name
- SSN / tax ID
- full payment/trade record
- raw private notes
- secrets
- API keys
- unrestricted PII

## 6. BFF Responsibilities

The Chatbot BFF must:

- validate auth
- check record-level entitlement
- enrich context server-side
- redact PII before prompt
- redact PII before audit/logging
- block prompt injection
- enforce tool permissions
- stream responses using SSE
- emit audit event
- emit observability event
- propagate correlation ID
- bypass semantic cache for restricted/record-specific queries

## 7. LOB Governance Model

Central team owns locked behavior:

- auth/session
- entitlement checks
- audit logging
- PII redaction
- BFF protocol
- model invocation policy
- prompt safety
- core conversation engine
- host shell lifecycle

LOBs may customize through governed contracts:

- persona
- greeting
- theme
- suggested prompts
- feature flags
- approved domain tools
- UI slots
- lifecycle hooks
- workflow triggers

LOBs must not fork the core ChatbotMFE.

## 8. Required Tests

Add tests proving:

- selecting a Payments record updates chatbot context
- selecting a Trade record updates chatbot context
- navigation does not call BFF
- chat submission calls BFF
- BFF rejects unauthorized record access
- PII is redacted from prompt/logs
- prompt injection is blocked
- SSE stream emits token chunks
- chatbot survives route changes

## 9. Review Standard

Before finishing any implementation, run or prepare:

```bash
pnpm typecheck
pnpm test
pnpm build
bash scripts/verify-architecture.sh
```

Also run security review for:

- direct AI calls from frontend
- raw PII in context events
- missing entitlement checks
- unsafe logs
- unsafe caching
- missing correlation IDs
