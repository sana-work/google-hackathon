const SENSITIVE_KEYS = new Set([
  "accountNumber",
  "customerName",
  "ssn",
  "taxId",
  "beneficiaryBankAccount",
  "routingNumber",
  "dateOfBirth"
]);

export function redactSensitiveData<T>(value: T): T {
  if (Array.isArray(value)) {
    return value.map(redactSensitiveData) as T;
  }

  if (value && typeof value === "object") {
    const output: Record<string, unknown> = {};
    for (const [key, nested] of Object.entries(value as Record<string, unknown>)) {
      output[key] = SENSITIVE_KEYS.has(key) ? "[REDACTED]" : redactSensitiveData(nested);
    }
    return output as T;
  }

  return value;
}
