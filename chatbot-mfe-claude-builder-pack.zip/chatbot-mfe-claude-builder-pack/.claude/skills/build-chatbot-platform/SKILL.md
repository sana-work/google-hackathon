---
description: Build the full Chatbot MFE platform using contracts-first implementation, frontend/backend separation, BFF gateway, event-driven navigation context, and governed LOB extension model.
---

# Build Chatbot MFE Platform

Follow this build order.

## Phase 1 — Contracts

Build `packages/contracts`.

Include:
- `CHATBOT_CONTEXT_CHANGED`
- `ChatbotContextEventSchema`
- `ChatMessageRequestSchema`
- `ChatStreamEventSchema`
- `LobConfigSchema`
- `ToolRegistrationSchema`
- `AuditEventSchema`
- `ObservabilityEventSchema`

Use Zod and TypeScript.

## Phase 2 — BFF

Build `services/chatbot-bff`.

Include:
- Fastify
- `POST /api/chat/stream`
- `GET /health`
- mock auth
- entitlement check
- server-side context enrichment
- PII redaction
- prompt injection check
- audit logger
- observability logger
- mock AI streaming response via SSE

## Phase 3 — Frontend

Build:
- `apps/shell`
- `apps/chatbot-mfe`
- `apps/payments-mfe`
- `apps/trade-mfe`

Rules:
- ChatbotMFE is mounted once by host shell.
- Business MFEs emit context events.
- ChatbotMFE listens passively.
- Navigation never calls BFF.
- Chat submit calls BFF.
- Use SSE for streaming.

## Phase 4 — Governance

Add:
- LOB config examples
- plugin registration examples
- locked/configurable/extensible model
- security comments
- observability comments

## Phase 5 — Tests

Add tests for:
- event schema
- no backend call on navigation
- backend call on chat submit
- entitlement rejection
- redaction
- SSE streaming
- chatbot persistence
