#!/usr/bin/env bash
set -euo pipefail

if command -v pnpm >/dev/null 2>&1 && [ -f package.json ]; then
  pnpm format >/dev/null 2>&1 || true
fi

exit 0
