import React, { useState } from "react";
import { createRoot } from "react-dom/client";
import "./style.css";

function App() {
  const [active, setActive] = useState<"payments" | "trade">("payments");
  return (
    <main>
      <header><h1>Services Shared Ops UI Platform</h1></header>
      <nav>
        <button onClick={() => setActive("payments")}>Payments</button>
        <button onClick={() => setActive("trade")}>Trade</button>
      </nav>
      <section className="frame-area">
        {active === "payments" ? <iframe title="Payments MFE" src="http://localhost:3002" /> : <iframe title="Trade MFE" src="http://localhost:3003" />}
      </section>
      <iframe title="Chatbot MFE" className="chatbot-frame" src="http://localhost:3001" />
    </main>
  );
}

createRoot(document.getElementById("root")!).render(<App />);
