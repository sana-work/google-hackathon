Use the security-review-chatbot skill and security-guardian agent.

Review the full repo for:
- direct AI calls from frontend
- raw PII in context events
- missing entitlement checks
- unsafe logs
- unsafe cache
- missing prompt-injection checks
- missing audit events
- missing correlation IDs

Provide critical/high/medium issues and required code changes.
