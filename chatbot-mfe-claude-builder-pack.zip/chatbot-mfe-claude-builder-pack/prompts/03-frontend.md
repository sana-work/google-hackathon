Use the frontend-architect agent.

Implement:
- apps/shell
- apps/chatbot-mfe
- apps/payments-mfe
- apps/trade-mfe

Required:
- Shell mounts ChatbotMFE once as sibling runtime.
- PaymentsMFE and TradeMFE emit `CHATBOT_CONTEXT_CHANGED` events with safe context only.
- ChatbotMFE listens to event and updates context.
- ChatbotMFE does not call BFF on context update.
- ChatbotMFE calls BFF only when user submits chat.
- ChatbotMFE consumes SSE response and renders stream.
- UI is keyboard accessible and uses aria-live for streamed messages.
