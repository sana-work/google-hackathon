#!/usr/bin/env bash
set -euo pipefail

FAIL=0

echo "[verify] Checking frontend does not reference AI providers..."
if [ -d apps ] && grep -RInE "openai|anthropic|bedrock|azure.*openai|AI_PLATFORM_API_KEY|ANTHROPIC_API_KEY|OPENAI_API_KEY" apps/ --exclude-dir=node_modules --exclude-dir=dist --exclude-dir=build 2>/dev/null; then
  echo "[FAIL] Frontend contains direct AI provider reference."
  FAIL=1
else
  echo "[PASS] No direct AI references in frontend."
fi

echo "[verify] Checking frontend does not contain obvious raw PII fields..."
if [ -d apps ] && grep -RInE "accountNumber|ssn|taxId|customerName|beneficiaryBankAccount|routingNumber|dateOfBirth" apps/*/src --exclude-dir=node_modules --exclude-dir=dist --exclude-dir=build 2>/dev/null; then
  echo "[FAIL] Possible raw PII found in frontend source."
  FAIL=1
else
  echo "[PASS] No obvious raw PII fields in frontend."
fi

echo "[verify] Checking context event name exists in contracts..."
if ! grep -R "CHATBOT_CONTEXT_CHANGED" packages/contracts/src >/dev/null 2>&1; then
  echo "[FAIL] CHATBOT_CONTEXT_CHANGED not found in contracts."
  FAIL=1
else
  echo "[PASS] Context event contract found."
fi

echo "[verify] Checking BFF has entitlement and redaction placeholders..."
if [ -d services/chatbot-bff/src ]; then
  if ! grep -RInE "entitlement|canAccess|authorize" services/chatbot-bff/src >/dev/null 2>&1; then
    echo "[FAIL] Entitlement check not found in BFF source."
    FAIL=1
  else
    echo "[PASS] Entitlement logic found."
  fi
  if ! grep -RInE "redact|PII|sanitize" services/chatbot-bff/src >/dev/null 2>&1; then
    echo "[FAIL] Redaction logic not found in BFF source."
    FAIL=1
  else
    echo "[PASS] Redaction logic found."
  fi
else
  echo "[WARN] BFF source directory not present yet."
fi

if [ "$FAIL" -ne 0 ]; then
  echo "Architecture verification failed."
  exit 1
fi

echo "Architecture verification passed."
