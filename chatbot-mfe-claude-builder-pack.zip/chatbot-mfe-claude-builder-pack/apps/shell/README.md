# Shell App Note

This starter uses iframes as a simple local demo shell. Real Module Federation should mount remotes in the same browser window, enabling `window.dispatchEvent` / `window.addEventListener` communication directly.

Ask Claude Code to replace the iframe demo with Webpack 5 Module Federation or Vite federation if your enterprise standard allows.

Important: If you keep iframes, browser CustomEvent will not cross iframe boundaries. You would need `postMessage` or BroadcastChannel. The deck assumes same-window MFEs.
