#!/usr/bin/env bash
set -euo pipefail

if [ ! -d apps ]; then
  exit 0
fi

if grep -RInE "openai|anthropic|bedrock|azure.*openai|AI_PLATFORM_API_KEY|ANTHROPIC_API_KEY|OPENAI_API_KEY" apps/ --exclude-dir=node_modules --exclude-dir=dist --exclude-dir=build 2>/dev/null; then
  echo "BLOCKED: Frontend appears to contain a direct AI platform reference."
  echo "Frontend must call Chatbot BFF only."
  exit 2
fi

exit 0
