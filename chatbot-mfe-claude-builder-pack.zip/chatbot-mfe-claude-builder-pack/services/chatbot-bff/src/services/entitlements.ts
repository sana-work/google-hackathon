import type { ChatbotContextEvent } from "@platform/contracts";
import type { MockUser } from "./auth.js";

export function canAccessContext(user: MockUser, context: ChatbotContextEvent): boolean {
  if (!user.allowedLobs.includes(context.lob)) return false;
  if (context.classification === "restricted" && !user.roles.includes("RESTRICTED_ACCESS")) return false;
  return true;
}
