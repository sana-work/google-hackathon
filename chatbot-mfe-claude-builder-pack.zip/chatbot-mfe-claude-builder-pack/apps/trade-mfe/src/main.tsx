import React from "react";
import { createRoot } from "react-dom/client";
import { CHATBOT_CONTEXT_CHANGED, makeCorrelationId } from "@platform/contracts";
import "./style.css";

const trades = [
  { id: "TRD-9001", status: "Settlement Pending", market: "NA" },
  { id: "TRD-9002", status: "Client Confirmation Needed", market: "EMEA" }
];

function selectTrade(trade: (typeof trades)[number]) {
  window.dispatchEvent(new CustomEvent(CHATBOT_CONTEXT_CHANGED, {
    detail: {
      eventVersion: "1.0",
      sourceMfe: "TradeMFE",
      lob: "Trade",
      contextType: "trade_record_selected",
      contextId: trade.id,
      safeSummary: { status: trade.status, market: trade.market },
      classification: "confidential",
      timestamp: new Date().toISOString(),
      ttlSeconds: 900,
      correlationId: makeCorrelationId()
    }
  }));
}

function App() {
  return <main><h2>Trade MFE</h2>{trades.map((t) => <button key={t.id} onClick={() => selectTrade(t)}>{t.id} — {t.status}</button>)}</main>;
}

createRoot(document.getElementById("root")!).render(<App />);
