import { z } from "zod";

export const CHATBOT_CONTEXT_CHANGED = "CHATBOT_CONTEXT_CHANGED" as const;

export const ClassificationSchema = z.enum([
  "public",
  "internal",
  "confidential",
  "restricted"
]);

const SafePrimitiveSchema = z.union([z.string(), z.number(), z.boolean(), z.null()]);

export const ChatbotContextEventSchema = z.object({
  eventVersion: z.literal("1.0"),
  sourceMfe: z.string().min(1),
  lob: z.string().min(1),
  contextType: z.string().min(1),
  contextId: z.string().min(1),
  route: z.string().optional(),
  safeSummary: z.record(SafePrimitiveSchema).optional(),
  classification: ClassificationSchema,
  permissionsHint: z.record(z.boolean()).optional(),
  timestamp: z.string().datetime(),
  ttlSeconds: z.number().int().min(30).max(3600),
  correlationId: z.string().min(8)
});

export type ChatbotContextEvent = z.infer<typeof ChatbotContextEventSchema>;

export const ChatMessageRequestSchema = z.object({
  conversationId: z.string().min(1),
  messageId: z.string().min(1),
  userMessage: z.string().min(1).max(4000),
  context: ChatbotContextEventSchema.optional(),
  clientTimestamp: z.string().datetime()
});

export type ChatMessageRequest = z.infer<typeof ChatMessageRequestSchema>;

export const ChatStreamEventSchema = z.discriminatedUnion("type", [
  z.object({ type: z.literal("metadata"), correlationId: z.string(), conversationId: z.string(), messageId: z.string() }),
  z.object({ type: z.literal("token"), text: z.string() }),
  z.object({ type: z.literal("policy_block"), reason: z.string() }),
  z.object({ type: z.literal("error"), message: z.string(), recoverable: z.boolean() }),
  z.object({ type: z.literal("done"), finishReason: z.string() })
]);

export type ChatStreamEvent = z.infer<typeof ChatStreamEventSchema>;

export const ToolRegistrationSchema = z.object({
  toolName: z.string().min(1),
  lob: z.string().min(1),
  description: z.string().min(1),
  accessLevel: z.enum(["read", "write", "workflow"]),
  requiresHumanConfirmation: z.boolean(),
  approvedByCentralTeam: z.boolean()
});

export type ToolRegistration = z.infer<typeof ToolRegistrationSchema>;

export const LobConfigSchema = z.object({
  lob: z.string().min(1),
  personaName: z.string().min(1),
  greeting: z.string().min(1),
  suggestedPrompts: z.array(z.string()).max(10),
  enabledTools: z.array(z.string()),
  theme: z.object({ primaryColor: z.string().regex(/^#[0-9A-Fa-f]{6}$/) }).optional()
});

export type LobConfig = z.infer<typeof LobConfigSchema>;

export const AuditEventSchema = z.object({
  eventType: z.string(),
  correlationId: z.string(),
  conversationId: z.string().optional(),
  lob: z.string().optional(),
  userIdHash: z.string(),
  action: z.string(),
  outcome: z.enum(["allowed", "denied", "blocked", "error"]),
  classification: ClassificationSchema.optional(),
  timestamp: z.string().datetime()
});

export type AuditEvent = z.infer<typeof AuditEventSchema>;

export const ObservabilityEventSchema = z.object({
  eventType: z.string(),
  correlationId: z.string(),
  lob: z.string().optional(),
  metricName: z.string(),
  metricValue: z.number(),
  unit: z.string(),
  timestamp: z.string().datetime(),
  attributes: z.record(z.union([z.string(), z.number(), z.boolean()])).optional()
});

export type ObservabilityEvent = z.infer<typeof ObservabilityEventSchema>;

export function isContextExpired(event: ChatbotContextEvent, now = Date.now()): boolean {
  const eventTime = Date.parse(event.timestamp);
  return now > eventTime + event.ttlSeconds * 1000;
}

export function makeCorrelationId(prefix = "corr"): string {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}
