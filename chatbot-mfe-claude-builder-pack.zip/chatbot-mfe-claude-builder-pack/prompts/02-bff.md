Use the bff-architect agent.

Implement `services/chatbot-bff` as Fastify TypeScript.

Required endpoints:
- GET /health
- POST /api/chat/stream

Required behavior:
- validate request using shared contracts
- mock auth
- entitlement check before enrichment
- server-side data adapter
- PII redaction before prompt
- PII redaction before logs
- prompt-injection policy guard
- audit logger
- observability logger
- SSE token streaming
- mock AI client

Do not expose credentials.
Do not trust frontend context blindly.
Do not log raw PII.
