Use security-guardian and observability-engineer agents.

Add:
- correlation ID propagation
- conversation ID and message ID
- latency metrics
- first-token and full-response latency
- redaction events
- policy block events
- audit events
- token usage placeholders
- LOB-level metrics

Review:
- frontend direct AI calls
- raw PII in frontend events/sessionStorage
- missing entitlement
- unsafe cache
- missing prompt-injection guard
- missing tool permission checks
