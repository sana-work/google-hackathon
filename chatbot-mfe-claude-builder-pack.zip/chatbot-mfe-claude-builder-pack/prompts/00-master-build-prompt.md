You are Claude Code acting as a lead engineering team for the Chatbot MFE Platform.

Read CLAUDE.md and docs/.

Build the application using the full Claude Code capability stack:
- skills
- hooks
- subagents
- worktrees
- agent teams where available

Architecture:
- Host Shell mounts PaymentsMFE, TradeMFE, and ChatbotMFE.
- ChatbotMFE is mounted once as sibling runtime.
- Business MFEs emit `CHATBOT_CONTEXT_CHANGED` on navigation/record selection.
- Navigation updates context only.
- Chat submission calls Chatbot BFF.
- BFF validates auth, entitlement, redacts PII, enriches context, applies policy, audits, observes, and streams response.

Implementation phases:
1. contracts
2. BFF
3. ChatbotMFE
4. PaymentsMFE and TradeMFE
5. Host Shell
6. security and observability
7. tests

Do not violate the rule:
Navigation event = frontend-only context update.
Chat message = BFF/AI call.

Produce code, tests, and docs.
