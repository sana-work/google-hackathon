# Architecture Summary

## Decision

Build the chatbot as a centrally owned, shell-mounted Chatbot MFE, not as a shared component embedded independently in every business MFE.

## Why

The chatbot requires:

- independent release lifecycle
- persistent conversation state across navigation
- governed LOB customization
- centralized security and observability
- BFF-based AI access
- passive context collection without backend/token cost

## Main Flow

```text
User navigates/selects record
  → Business MFE emits CHATBOT_CONTEXT_CHANGED
  → ChatbotMFE silently updates local context
  → no backend call

User sends chat message
  → ChatbotMFE calls Chatbot BFF
  → BFF validates auth + entitlement
  → BFF enriches context server-side
  → BFF redacts sensitive data
  → BFF calls AI platform or mock AI
  → BFF streams response to ChatbotMFE
```

## Challenged Areas

- MFE vs shared component should be framed as platform runtime vs duplicated embedded widget.
- Browser CustomEvents are fine for same-window communication, but may need stronger abstractions later.
- Context accumulation can become privacy risk unless TTL and classification are enforced.
- Per-LOB BFFs require central policy contract to prevent inconsistent controls.
- Semantic caching is risky for record-specific or entitlement-sensitive responses.
- Plugin API must not become a backdoor around central security.
