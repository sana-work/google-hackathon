Implement `packages/contracts` first.

Use TypeScript and Zod.

Create:
- constants
- ChatbotContextEventSchema
- ChatMessageRequestSchema
- ChatStreamEventSchema
- LobConfigSchema
- ToolRegistrationSchema
- AuditEventSchema
- ObservabilityEventSchema
- helper functions
- tests

The event contract must enforce safe frontend context and require TTL, classification, timestamp, and correlationId.
