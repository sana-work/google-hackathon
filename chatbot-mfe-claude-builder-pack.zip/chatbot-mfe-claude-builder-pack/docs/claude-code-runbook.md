# Claude Code Runbook

## Initial Session

```bash
claude
```

Inside Claude:

```text
/init
/permissions
```

Then:

```text
Read CLAUDE.md. Use the build-chatbot-platform skill. Plan first. Use subagents, hooks, worktrees, and agent teams where useful.
```

## Parallel Worktrees

```bash
claude -w contracts
claude -w bff-service
claude -w frontend-apps
claude -w security-review
claude -w qa-tests
```

## Suggested Agent Team

- Lead architect
- Contracts engineer
- Frontend engineer
- BFF engineer
- Security engineer
- Observability engineer
- QA engineer

## Build Order

1. Contracts
2. BFF
3. ChatbotMFE
4. Business MFEs
5. Shell
6. Security + observability
7. Tests

## Final Review

Ask Claude:

```text
Use the architecture-reviewer, security-guardian, and qa-engineer agents. Produce a final release readiness report.
```
