export async function* streamMockAiResponse(message: string, safeContext: Record<string, unknown>) {
  const contextText = safeContext && Object.keys(safeContext).length > 0
    ? ` using the authorized context for record ${String(safeContext.recordId ?? "unknown")}`
    : "";

  const response = `I reviewed your question${contextText}. The likely issue is available from server-side enriched context. This is a mock streamed response for: ${message}`;
  const tokens = response.split(/(\s+)/).filter(Boolean);

  for (const token of tokens) {
    await new Promise((resolve) => setTimeout(resolve, 15));
    yield token;
  }
}
