import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import { CHATBOT_CONTEXT_CHANGED, ChatbotContextEventSchema, type ChatbotContextEvent, makeCorrelationId } from "@platform/contracts";
import "./style.css";

type Message = { role: "user" | "assistant"; text: string };

function useChatbotContext() {
  const [context, setContext] = useState<ChatbotContextEvent | undefined>(() => {
    const raw = sessionStorage.getItem("chatbot.safeContext");
    if (!raw) return undefined;
    const parsed = ChatbotContextEventSchema.safeParse(JSON.parse(raw));
    return parsed.success ? parsed.data : undefined;
  });

  useEffect(() => {
    const handler = (event: Event) => {
      const custom = event as CustomEvent<unknown>;
      const parsed = ChatbotContextEventSchema.safeParse(custom.detail);
      if (!parsed.success) return;
      setContext(parsed.data);
      sessionStorage.setItem("chatbot.safeContext", JSON.stringify(parsed.data));
      // Important: no BFF call here. Navigation updates context only.
    };
    window.addEventListener(CHATBOT_CONTEXT_CHANGED, handler);
    return () => window.removeEventListener(CHATBOT_CONTEXT_CHANGED, handler);
  }, []);

  return context;
}

function ChatbotApp() {
  const context = useChatbotContext();
  const [open, setOpen] = useState(true);
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Message[]>([]);
  const conversationId = useMemo(() => makeCorrelationId("conv"), []);

  async function submit() {
    const userMessage = input.trim();
    if (!userMessage) return;
    setInput("");
    setMessages((prev) => [...prev, { role: "user", text: userMessage }, { role: "assistant", text: "" }]);

    const response = await fetch("http://localhost:4000/api/chat/stream", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: "Bearer demo" },
      body: JSON.stringify({
        conversationId,
        messageId: makeCorrelationId("msg"),
        userMessage,
        context,
        clientTimestamp: new Date().toISOString()
      })
    });

    if (!response.ok || !response.body) {
      setMessages((prev) => prev.map((m, idx) => idx === prev.length - 1 ? { ...m, text: "Unable to get response." } : m));
      return;
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const events = buffer.split("\n\n");
      buffer = events.pop() ?? "";
      for (const raw of events) {
        const dataLine = raw.split("\n").find((line) => line.startsWith("data: "));
        if (!dataLine) continue;
        const payload = JSON.parse(dataLine.slice(6));
        if (payload.text) {
          setMessages((prev) => prev.map((m, idx) => idx === prev.length - 1 ? { ...m, text: m.text + payload.text } : m));
        }
      }
    }
  }

  return (
    <aside className="chatbot" aria-label="Operations chatbot">
      <button className="chatbot-toggle" onClick={() => setOpen((v) => !v)} aria-expanded={open}>Chat</button>
      {open && (
        <section className="chatbot-panel">
          <header>
            <strong>Ops Assistant</strong>
            <small>{context ? `${context.lob}: ${context.contextId}` : "No active context"}</small>
          </header>
          <div className="messages" aria-live="polite">
            {messages.map((message, index) => <p key={index} className={message.role}>{message.text}</p>)}
          </div>
          <form onSubmit={(e) => { e.preventDefault(); void submit(); }}>
            <label className="sr-only" htmlFor="chat-input">Message</label>
            <input id="chat-input" value={input} onChange={(e) => setInput(e.target.value)} placeholder="Ask about current record" />
            <button type="submit">Send</button>
          </form>
        </section>
      )}
    </aside>
  );
}

createRoot(document.getElementById("root")!).render(<ChatbotApp />);
