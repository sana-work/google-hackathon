export type MockUser = {
  userIdHash: string;
  roles: string[];
  allowedLobs: string[];
};

export function getMockUser(_authorizationHeader?: unknown): MockUser {
  return {
    userIdHash: "user_hash_demo_123",
    roles: ["PAYMENTS_ANALYST", "TRADE_VIEWER"],
    allowedLobs: ["Payments", "Trade"]
  };
}
