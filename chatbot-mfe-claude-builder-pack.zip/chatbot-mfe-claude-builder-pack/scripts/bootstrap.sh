#!/usr/bin/env bash
set -euo pipefail

corepack enable || true
pnpm install
pnpm typecheck || true

echo "Bootstrap complete. Start Claude Code with: claude"
echo "Then ask it to use the build-chatbot-platform skill."
