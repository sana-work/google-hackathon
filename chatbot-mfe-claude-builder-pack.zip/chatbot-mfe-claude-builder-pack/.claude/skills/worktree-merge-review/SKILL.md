---
description: Review and merge Claude Code worktree outputs safely into main branch.
---

# Worktree Merge Review

Use this procedure for each worktree.

## 1. Inspect

```bash
git status
git diff --stat
git diff
```

## 2. Run checks

```bash
pnpm typecheck
pnpm test
pnpm build
bash scripts/verify-architecture.sh
```

## 3. Review architecture boundaries

Confirm:
- frontend does not call AI directly
- navigation does not call BFF
- chat submit calls BFF
- BFF checks entitlement
- logs are redacted
- context event does not contain raw PII

## 4. Merge

Commit worktree changes and merge through normal git workflow.
Do not merge failing security checks.
