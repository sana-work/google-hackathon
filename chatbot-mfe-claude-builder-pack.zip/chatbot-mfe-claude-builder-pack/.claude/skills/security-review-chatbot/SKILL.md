---
description: Perform security and governance review for Chatbot MFE architecture, especially frontend trust boundary, BFF gateway, PII redaction, entitlement, and AI guardrails.
---

# Security Review Chatbot Platform

Review the repo for these issues.

## Frontend

Block:
- direct AI Platform calls
- business API enrichment from browser
- raw PII in context events
- raw PII in sessionStorage
- secrets in frontend config

## BFF

Require:
- auth validation
- entitlement check before enrichment
- PII redaction before prompt
- PII redaction before logs
- prompt injection filtering
- rate limiting placeholder
- audit logging
- correlation ID propagation

## AI Guardrails

Require:
- restricted content classification
- tool permission checks
- deny-by-default tool access
- human confirmation placeholder for sensitive actions
- no unsafe semantic cache for restricted records

## Output

Return:
- Critical findings
- High findings
- Medium findings
- Required code changes
