Read CLAUDE.md and all docs in docs/. Use the build-chatbot-platform skill.

Create a phase-by-phase implementation plan:
1. contracts
2. chatbot BFF
3. ChatbotMFE
4. PaymentsMFE / TradeMFE
5. Host Shell
6. security / observability
7. tests

Use subagents where helpful. Use worktrees for independent edits.

Do not violate: navigation updates context only; chat submission triggers BFF/AI work.
