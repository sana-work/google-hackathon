import type { FastifyInstance } from "fastify";
import { ChatMessageRequestSchema } from "@platform/contracts";
import { getMockUser } from "../services/auth.js";
import { canAccessContext } from "../services/entitlements.js";
import { enrichContext } from "../services/data-adapters.js";
import { redactSensitiveData } from "../services/redaction.js";
import { detectPromptInjection } from "../services/policy.js";
import { audit } from "../services/audit.js";
import { observe } from "../services/observability.js";
import { streamMockAiResponse } from "../services/mock-ai.js";

export async function registerChatRoutes(app: FastifyInstance) {
  app.post("/chat/stream", async (request, reply) => {
    const start = Date.now();
    const parsed = ChatMessageRequestSchema.safeParse(request.body);

    if (!parsed.success) {
      reply.code(400);
      return { error: "Invalid chat request", issues: parsed.error.flatten() };
    }

    const chatRequest = parsed.data;
    const user = getMockUser(request.headers.authorization);
    const correlationId = chatRequest.context?.correlationId ?? `corr-${Date.now()}`;

    if (detectPromptInjection(chatRequest.userMessage)) {
      audit({
        eventType: "policy.block",
        correlationId,
        conversationId: chatRequest.conversationId,
        lob: chatRequest.context?.lob,
        userIdHash: user.userIdHash,
        action: "chat.submit",
        outcome: "blocked",
        classification: chatRequest.context?.classification,
        timestamp: new Date().toISOString()
      });
      reply.code(400);
      return { error: "Message blocked by policy" };
    }

    if (chatRequest.context && !canAccessContext(user, chatRequest.context)) {
      audit({
        eventType: "entitlement.denied",
        correlationId,
        conversationId: chatRequest.conversationId,
        lob: chatRequest.context.lob,
        userIdHash: user.userIdHash,
        action: "context.enrich",
        outcome: "denied",
        classification: chatRequest.context.classification,
        timestamp: new Date().toISOString()
      });
      reply.code(403);
      return { error: "Not authorized for this record" };
    }

    const enriched = chatRequest.context ? await enrichContext(chatRequest.context) : undefined;
    const safeEnriched = redactSensitiveData(enriched ?? {});

    audit({
      eventType: "chat.accepted",
      correlationId,
      conversationId: chatRequest.conversationId,
      lob: chatRequest.context?.lob,
      userIdHash: user.userIdHash,
      action: "chat.submit",
      outcome: "allowed",
      classification: chatRequest.context?.classification,
      timestamp: new Date().toISOString()
    });

    observe({
      eventType: "chat.request",
      correlationId,
      lob: chatRequest.context?.lob,
      metricName: "bff.request.accepted",
      metricValue: 1,
      unit: "count",
      timestamp: new Date().toISOString()
    });

    reply.raw.writeHead(200, {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Correlation-Id": correlationId
    });

    const writeEvent = (event: string, data: unknown) => {
      reply.raw.write(`event: ${event}\n`);
      reply.raw.write(`data: ${JSON.stringify(data)}\n\n`);
    };

    writeEvent("metadata", {
      correlationId,
      conversationId: chatRequest.conversationId,
      messageId: chatRequest.messageId
    });

    let firstTokenMs: number | undefined;
    for await (const token of streamMockAiResponse(chatRequest.userMessage, safeEnriched)) {
      if (firstTokenMs === undefined) {
        firstTokenMs = Date.now() - start;
        observe({
          eventType: "latency.first_token",
          correlationId,
          lob: chatRequest.context?.lob,
          metricName: "first_token_latency_ms",
          metricValue: firstTokenMs,
          unit: "ms",
          timestamp: new Date().toISOString()
        });
      }
      writeEvent("token", { text: token });
    }

    observe({
      eventType: "latency.full_response",
      correlationId,
      lob: chatRequest.context?.lob,
      metricName: "full_response_latency_ms",
      metricValue: Date.now() - start,
      unit: "ms",
      timestamp: new Date().toISOString()
    });

    writeEvent("done", { finishReason: "stop" });
    reply.raw.end();
  });
}
