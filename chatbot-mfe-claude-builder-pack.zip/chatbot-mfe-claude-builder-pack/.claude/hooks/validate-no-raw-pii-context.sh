#!/usr/bin/env bash
set -euo pipefail

if [ ! -d apps ]; then
  exit 0
fi

# This is intentionally conservative. Rename safe demo variables if this blocks legitimate examples.
if grep -RInE "accountNumber|ssn|taxId|customerName|beneficiaryBankAccount|routingNumber|dateOfBirth" apps/*/src --exclude-dir=node_modules --exclude-dir=dist --exclude-dir=build 2>/dev/null; then
  echo "BLOCKED: Possible raw PII in frontend source/context."
  echo "Context events must use safe summaries and record references only."
  exit 2
fi

exit 0
