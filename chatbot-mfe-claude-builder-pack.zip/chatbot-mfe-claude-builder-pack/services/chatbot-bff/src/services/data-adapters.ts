import type { ChatbotContextEvent } from "@platform/contracts";

export async function enrichContext(context: ChatbotContextEvent): Promise<Record<string, unknown>> {
  // Demo server-side enrichment only. Replace with enterprise business APIs.
  if (context.lob === "Payments") {
    return {
      recordId: context.contextId,
      status: context.safeSummary?.status ?? "Unknown",
      failureReason: "Beneficiary bank code validation failed",
      // These fields intentionally demonstrate backend-only raw data that must be redacted before prompt/logs.
      accountNumber: "1234567890",
      customerName: "REDACT_ME"
    };
  }

  if (context.lob === "Trade") {
    return {
      recordId: context.contextId,
      status: context.safeSummary?.status ?? "Unknown",
      settlementStatus: "Pending client confirmation",
      customerName: "REDACT_ME"
    };
  }

  return { recordId: context.contextId, status: context.safeSummary?.status ?? "Unknown" };
}
