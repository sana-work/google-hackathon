import type { AuditEvent } from "@platform/contracts";
import { redactSensitiveData } from "./redaction.js";

export function audit(event: AuditEvent): void {
  // Replace with Kafka / enterprise audit pipeline.
  console.log(JSON.stringify({ stream: "audit", event: redactSensitiveData(event) }));
}
