# Chatbot MFE Claude Builder Pack

This pack is a Claude Code–ready scaffold for building the **Chatbot MFE Architecture** discussed in the slides:

- Host Shell mounts business MFEs and the Chatbot MFE once.
- Chatbot MFE is a sibling platform runtime, not a child component embedded separately in each LOB app.
- Business MFEs emit passive browser events when the user navigates/selects records.
- Navigation updates context only.
- Chat submission triggers BFF / AI work.
- Frontend never calls AI Platform directly.
- BFF performs authentication, entitlement, context enrichment, redaction, audit, observability, and SSE streaming.
- LOB customization is governed through config, plugins, UI slots, lifecycle hooks, and approved tools.

## Quick Start

```bash
unzip chatbot-mfe-claude-builder-pack.zip
cd chatbot-mfe-claude-builder-pack
corepack enable
pnpm install
claude
```

Inside Claude Code:

```text
/init
/permissions
```

Then paste:

```text
Use the build-chatbot-platform skill. Read CLAUDE.md first. Build the application in phases: contracts, BFF, frontend MFEs, shell, observability, security, tests. Use subagents, hooks, and worktrees where useful. Do not violate the rule: navigation updates context only; chat submission triggers BFF/AI work.
```

## Worktree Execution

For parallel work:

```bash
claude -w contracts
claude -w bff-service
claude -w frontend-apps
claude -w security-review
claude -w qa-tests
```

Each worktree should operate on a specific scope, then merge back through normal git review.

## Repo Layout

```text
.claude/
  agents/           Specialized subagents
  skills/           Repeatable Claude Code skills
  hooks/            Guardrail scripts
  commands/         Prompt templates for repeatable slash-command style workflows
apps/
  shell/            Host shell, mounts MFEs
  chatbot-mfe/      Platform chatbot MFE
  payments-mfe/     Demo business MFE
  trade-mfe/        Demo business MFE
services/
  chatbot-bff/      Backend-for-Frontend secure gateway
packages/
  contracts/        Shared event/API schemas
docs/               Architecture notes, event contract, governance, runbook
prompts/            Copy/paste prompts for Claude Code phases
scripts/            Bootstrap and verification helpers
```

## The Most Important Architecture Rule

```text
Navigation event = frontend-only context update
Chat message     = BFF / AI call
```

This rule must be enforced in code, tests, hooks, and reviews.
