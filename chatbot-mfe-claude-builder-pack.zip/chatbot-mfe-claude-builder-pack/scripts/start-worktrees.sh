#!/usr/bin/env bash
set -euo pipefail

for wt in contracts bff-service frontend-apps security-review qa-tests; do
  echo "Starting Claude Code worktree: $wt"
  echo "Run manually in a separate terminal: claude -w $wt"
done
