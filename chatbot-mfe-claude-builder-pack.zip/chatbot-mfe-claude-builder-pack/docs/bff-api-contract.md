# BFF API Contract

## Health

```http
GET /health
```

Response:

```json
{
  "status": "ok"
}
```

## Chat Stream

```http
POST /api/chat/stream
Content-Type: application/json
Accept: text/event-stream
```

Request:

```json
{
  "conversationId": "conv-123",
  "messageId": "msg-123",
  "userMessage": "Why did this payment fail?",
  "context": {
    "eventVersion": "1.0",
    "sourceMfe": "PaymentsMFE",
    "lob": "Payments",
    "contextType": "payment_record_selected",
    "contextId": "PAY-123",
    "classification": "confidential",
    "timestamp": "2026-05-20T10:00:00Z",
    "ttlSeconds": 900,
    "correlationId": "corr-123"
  }
}
```

SSE events:

```text
event: metadata
data: {"correlationId":"corr-123","conversationId":"conv-123"}

event: token
data: {"text":"This"}

event: token
data: {"text":" payment"}

event: done
data: {"finishReason":"stop"}
```

## BFF Must Perform

1. Validate auth.
2. Validate request schema.
3. Check entitlement for `contextId`.
4. Enrich context server-side.
5. Redact sensitive fields.
6. Apply prompt-injection policy.
7. Create audit event.
8. Emit observability events.
9. Stream response.
